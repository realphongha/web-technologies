<?php
    echo "<p>Thêm thành công. quay lại <a href='show.php'>trang danh sách</a></p>";
?>