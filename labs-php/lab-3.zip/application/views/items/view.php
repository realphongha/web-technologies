
<h2><?php echo $todo->item_name?></h2>

	<a class="big" href="../../../items/delete/<?php echo $todo->id?>">
	<span class="item">
	Delete this item
	</span>
	</a><br/>
