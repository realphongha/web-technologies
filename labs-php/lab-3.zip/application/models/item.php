<?php

class Item extends Model {

}
