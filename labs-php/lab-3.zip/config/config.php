<?php
 
define ('DEVELOPMENT_ENVIRONMENT',true);
 
define('DB_NAME', 'web-technologies');
define('DB_USER', 'root');
define('DB_PASSWORD', 'moeden');
define('DB_HOST', '127.0.0.1:3306');